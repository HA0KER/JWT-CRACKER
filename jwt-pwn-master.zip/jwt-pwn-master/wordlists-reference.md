Wordlists Reference
====================


#### `rockyou.txt.tar.gz` ####
`https://github.com/danielmiessler/SecLists/raw/master/Passwords/Leaked-Databases/rockyou.txt.tar.gz`


#### `darkc0de.txt` ####
`https://github.com/danielmiessler/SecLists/raw/master/Passwords/darkc0de.txt`


#### `openwall.net-all.txt` ####
 `https://github.com/danielmiessler/SecLists/blob/master/Passwords/openwall.net-all.txt`


#### `john-the-ripper.txt` ####
`https://github.com/danielmiessler/SecLists/raw/master/Passwords/Software/john-the-ripper.txt`
